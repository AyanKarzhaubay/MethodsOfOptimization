﻿using System;
class MST
{
    static int V = 9, INF = 1000;

    // A utility function to find 
    // the vertex with minimum key 
    // value, from the set of vertices 
    // not yet included in MST 
    static int minKey(int[] key, bool[] mstSet)
    {

        // Initialize min value 
        int min = int.MaxValue, min_index = -1;

        for (int v = 0; v < V; v++)
            if (mstSet[v] == false && key[v] < min)
            {
                min = key[v];
                min_index = v;
            }

        return min_index;
    }

    // A utility function to print 
    // the constructed MST stored in 
    // parent[] 
    static void printMST(int[] parent, int[,] graph)
    {
        Console.WriteLine("Edge \tWeight");
        for (int i = 1; i < V; i++)
            Console.WriteLine(parent[i] + " - " + i + "\t" + graph[i, parent[i]]);
    }

    // Function to construct and 
    // print MST for a graph represented 
    // using adjacency matrix representation 
    static void primMST(int[,] graph)
    {

        // Array to store constructed MST 
        int[] parent = new int[V];

        // Key values used to pick 
        // minimum weight edge in cut 
        int[] key = new int[V];

        // To represent set of vertices 
        // not yet included in MST 
        bool[] mstSet = new bool[V];

        // Initialize all keys 
        // as INFINITE 
        for (int i = 0; i < V; i++)
        {
            key[i] = int.MaxValue;
            mstSet[i] = false;
        }

        // Always include first 1st vertex in MST. 
        // Make key 0 so that this vertex is 
        // picked as first vertex 
        // First node is always root of MST 
        key[0] = 0;
        parent[0] = -1;

        // The MST will have V vertices 
        for (int count = 0; count < V - 1; count++)
        {

            // Pick thd minimum key vertex 
            // from the set of vertices 
            // not yet included in MST 
            int u = minKey(key, mstSet);

            // Add the picked vertex 
            // to the MST Set 
            mstSet[u] = true;

            // Update key value and parent 
            // index of the adjacent vertices 
            // of the picked vertex. Consider 
            // only those vertices which are 
            // not yet included in MST 
            for (int v = 0; v < V; v++)

                // graph[u][v] is non zero only 
                // for adjacent vertices of m 
                // mstSet[v] is false for vertices 
                // not yet included in MST Update 
                // the key only if graph[u][v] is 
                // smaller than key[v] 
                if (graph[u, v] != 0 && mstSet[v] == false
                    && graph[u, v] < key[v])
                {
                    parent[v] = u;
                    key[v] = graph[u, v];
                }
        }

        printMST(parent, graph);
    }
    class Program
    {
        public static void SimmetrialiManderdiBeru(int[,] a)
        {
            for (int i = 0; i < a.GetLength(0); i++)
            {
                for (int j = 0; j < a.GetLength(1); j++)
                {
                    if (i < j)
                    {
                        a[j, i] = a[i, j];
                    }
                }
            }
        }
        public static void Main()
        {
            int[,] graph = new int[,] {   { INF, 50, 70, 75, 45, 90, 85, 80, 5 },
                                      { 0, INF, 25, 35, 55, 60, 10, 85, 70 },
                                      { 0, 0, INF, 50, INF, 30, 90, 80, 35 },
                                      { 0, 0, 0, INF, 25, 5, 55, 60, 65 },
                                      { 0, 0, 0, 0, INF, 45, 75, 95, 40 },
                                      { 0, 0, 0, 0, 0, INF, 15, 20, 90 },
                                      { 0, 0, 0, 0, 0, 0, INF, 30, INF },
                                      { 0, 0, 0, 0, 0, 0, 0, INF, 70 },
                                      { 0, 0, 0, 0, 0, 0, 0, 0, INF } };

            SimmetrialiManderdiBeru(graph);

            primMST(graph);

            Console.ReadKey();
        }
    }
}